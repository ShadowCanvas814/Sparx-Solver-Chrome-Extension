async function sendToGemini(base64Image, tabId, instruction) {
    // Get both the API key AND the selected model
    const data = await chrome.storage.local.get(['gemini_api_key', 'gemini_model']);
    const API_KEY = data.gemini_api_key;
    const MODEL = data.gemini_model || "gemini-2.5-flash-lite"; // Default fallback

    if (!API_KEY) {
        chrome.tabs.sendMessage(tabId, { action: "display_response", data: "❌ No API Key found in options!" });
        return;
    }

    // URL now uses the dynamic model variable
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${API_KEY}`;

    try {
        const imageData = base64Image.split(',')[1];
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{
                    parts: [
                        { text: instruction },
                        { inline_data: { mime_type: "image/png", data: imageData } }
                    ]
                }]
            })
        });

        const json = await response.json();

        // Capture API-side errors (Invalid key, blocked request, etc.)
        if (json.error) {
            chrome.tabs.sendMessage(tabId, { action: "display_response", data: `❌ API Error: ${json.error.message}` });
            return;
        }

        if (json.candidates && json.candidates[0]?.content?.parts?.[0]?.text) {
            const aiResponse = json.candidates[0].content.parts[0].text.trim();
            
            // Flexible regex matching: Looks for 'CODE: 2B' or just a standalone bookwork code like '2B'
            const codeMatch = aiResponse.match(/CODE:\s*([0-9]{1,2}[A-Z])/i) || aiResponse.match(/\b([0-9]{1,2}[A-Z])\b/i);
            const foundCode = codeMatch ? codeMatch[1].toUpperCase() : "N/A";
            
            // Flexible response extraction
            const answerMatch = aiResponse.match(/ANSWER:\s*([\s\S]*)$/i);
            let cleanAnswer = "";

            if (answerMatch) {
                cleanAnswer = answerMatch[1].trim();
            } else {
                // Fallback: If it didn't explicitly use the tags, strip out structural remnants and provide clean text
                cleanAnswer = aiResponse
                    .replace(/CODE:\s*[0-9]{1,2}[A-Z]\s*\|?/i, "")
                    .replace(/ANSWER:/i, "")
                    .trim();
            }

            chrome.tabs.sendMessage(tabId, { 
                action: "save_and_display", 
                code: foundCode, 
                answer: cleanAnswer 
            });
        } else {
            chrome.tabs.sendMessage(tabId, { action: "display_response", data: "⚠️ Received empty response structure from AI." });
        }
    } catch (err) {
        chrome.tabs.sendMessage(tabId, { action: "display_response", data: "Error: " + err.message });
    }
}

chrome.runtime.onMessage.addListener((request, sender) => {
    if (request.action === "capture_screen") {
        chrome.tabs.captureVisibleTab(sender.tab.windowId, { format: "png" }, (dataUrl) => {
            sendToGemini(dataUrl, sender.tab.id, request.instruction);
        });
    }
});